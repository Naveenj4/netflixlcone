import React, { useEffect, useState } from 'react';
import { Play, Info, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import './Banner.css';
import { Movie } from '../types';
import { getFeaturedMovie, getGenreName } from '../services/movieService';

const Banner: React.FC = () => {
  const [movie, setMovie] = useState<Movie | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadFeaturedMovie = async () => {
      setIsLoading(true);
      try {
        const featuredMovie = await getFeaturedMovie();
        setMovie(featuredMovie);
      } catch (error) {
        console.error('Error loading featured movie:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadFeaturedMovie();
  }, []);

  // Function to truncate description if it's too long
  const truncate = (str: string, n: number) => {
    return str?.length > n ? str.substr(0, n - 1) + '...' : str;
  };

  if (isLoading) {
    return (
      <div className="banner banner__loading">
        <div className="banner__loading-pulse"></div>
      </div>
    );
  }

  return (
    <header 
      className="banner"
      aria-label={movie?.title ? `Featured: ${movie.title}` : 'Featured content'}
    >
      {movie && (
        <>
          <img 
            src={movie.backdrop_path} 
            alt={movie.title} 
            className="banner__background"
          />
          <div className="banner__overlay"></div>
          <div className="container banner__contents">
            <h1 className="banner__title">{movie.title}</h1>
            
            <div className="banner__rating">
              <Star size={16} color="#FFD700" fill="#FFD700" />
              <span className="banner__rating-value">{movie.vote_average}/10</span>
              <span className="banner__release-year">
                {new Date(movie.release_date).getFullYear()}
              </span>
            </div>
            
            <div className="banner__genres">
              {movie.genre_ids.slice(0, 3).map((genreId) => (
                <span key={genreId} className="banner__genre">
                  {getGenreName(genreId)}
                </span>
              ))}
            </div>
            
            <p className="banner__description">
              {truncate(movie.overview, 150)}
            </p>
            
            <div className="banner__buttons">
              <button className="banner__button banner__button--play">
                <Play size={20} />
                Play
              </button>
              <Link to={`/movie/${movie.id}`} className="banner__button banner__button--info">
                <Info size={20} />
                More Info
              </Link>
            </div>
          </div>
          <div className="banner__fadeBottom"></div>
        </>
      )}
    </header>
  );
};

export default Banner;