import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, Bell, User } from 'lucide-react';
import './Navbar.css';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <div className="navbar-left">
          <Link to="/" className="navbar-logo">NETFLUX</Link>
          <ul className="navbar-links">
            <li className={location.pathname === '/' ? 'active' : ''}>
              <Link to="/">Home</Link>
            </li>
            <li className={location.pathname === '/browse' ? 'active' : ''}>
              <Link to="/browse">TV Shows</Link>
            </li>
            <li>
              <Link to="/browse">Movies</Link>
            </li>
            <li>
              <Link to="/browse">New & Popular</Link>
            </li>
            <li>
              <Link to="/browse">My List</Link>
            </li>
          </ul>
        </div>
        <div className="navbar-right">
          <div className={`search-container ${showSearch ? 'active' : ''}`}>
            <button 
              className="icon-button search-button"
              onClick={() => setShowSearch(!showSearch)}
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            {showSearch && (
              <input 
                type="text" 
                className="search-input" 
                placeholder="Titles, people, genres" 
                autoFocus
              />
            )}
          </div>
          <button className="icon-button" aria-label="Notifications">
            <Bell size={20} />
          </button>
          <div className="profile-dropdown">
            <button className="profile-button" aria-label="User profile">
              <User size={20} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;