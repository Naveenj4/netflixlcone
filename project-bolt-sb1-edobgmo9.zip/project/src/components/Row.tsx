import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Movie } from '../types';
import './Row.css';

interface RowProps {
  title: string;
  movies: Movie[];
  isLoading?: boolean;
}

const Row: React.FC<RowProps> = ({ title, movies, isLoading = false }) => {
  const rowRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (rowRef.current) {
      rowRef.current.scrollBy({
        left: -500,
        behavior: 'smooth'
      });
    }
  };

  const scrollRight = () => {
    if (rowRef.current) {
      rowRef.current.scrollBy({
        left: 500,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="row">
      <h2 className="row__title">{title}</h2>
      
      {isLoading ? (
        <div className="row__loading">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="row__loading-item"></div>
          ))}
        </div>
      ) : (
        <>
          <button 
            className="row__nav-button row__nav-button--left"
            onClick={scrollLeft}
            aria-label="Scroll left"
          >
            <ChevronLeft size={24} />
          </button>
          
          <div className="row__posters" ref={rowRef}>
            {movies.map(movie => (
              <div key={movie.id} className="row__poster-container">
                <Link to={`/movie/${movie.id}`}>
                  <img 
                    className="row__poster"
                    src={movie.poster_path}
                    alt={movie.title}
                    loading="lazy"
                  />
                  <div className="row__poster-info">
                    <div className="row__poster-title">{movie.title}</div>
                    <div className="row__poster-rating">
                      <Star size={12} color="#FFD700" fill="#FFD700" />
                      <span>{movie.vote_average.toFixed(1)}</span>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
          
          <button 
            className="row__nav-button row__nav-button--right"
            onClick={scrollRight}
            aria-label="Scroll right"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}
    </div>
  );
};

export default Row;