import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FilmIcon, Star } from 'lucide-react';
import { Movie, Genre } from '../types';
import { getMovieRows, getGenres } from '../services/movieService';
import './Browse.css';

const Browse: React.FC = () => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        const movieRows = await getMovieRows();
        const allMovies: Movie[] = [];
        
        // Combine all movies from different rows and deduplicate
        movieRows.forEach(row => {
          row.movies.forEach(movie => {
            if (!allMovies.some(m => m.id === movie.id)) {
              allMovies.push(movie);
            }
          });
        });
        
        setMovies(allMovies);
        setFilteredMovies(allMovies);
        
        const genresList = await getGenres();
        setGenres(genresList);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Apply genre filter
  useEffect(() => {
    if (selectedGenre === null) {
      setFilteredMovies(movies);
    } else {
      const filtered = movies.filter(movie => 
        movie.genre_ids.includes(selectedGenre)
      );
      setFilteredMovies(filtered);
    }
  }, [selectedGenre, movies]);

  return (
    <div className="browse">
      <div className="container">
        <div className="browse__header">
          <h1 className="browse__title">Browse All</h1>
          
          <div className="browse__filters">
            <button 
              className={`browse__filter ${selectedGenre === null ? 'active' : ''}`}
              onClick={() => setSelectedGenre(null)}
            >
              All
            </button>
            
            {genres.map(genre => (
              <button 
                key={genre.id}
                className={`browse__filter ${selectedGenre === genre.id ? 'active' : ''}`}
                onClick={() => setSelectedGenre(genre.id)}
              >
                {genre.name}
              </button>
            ))}
          </div>
        </div>
        
        {isLoading ? (
          <div className="browse__loading">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="browse__loading-item"></div>
            ))}
          </div>
        ) : filteredMovies.length > 0 ? (
          <div className="browse__grid">
            {filteredMovies.map(movie => (
              <div key={movie.id} className="browse__movie">
                <Link to={`/movie/${movie.id}`}>
                  <img 
                    src={movie.poster_path}
                    alt={movie.title}
                    className="browse__poster"
                    loading="lazy"
                  />
                  <div className="browse__movie-info">
                    <h3 className="browse__movie-title">{movie.title}</h3>
                    <div className="browse__movie-meta">
                      <div className="browse__movie-rating">
                        <Star size={12} color="#FFD700" fill="#FFD700" />
                        <span>{movie.vote_average.toFixed(1)}</span>
                      </div>
                      <div className="browse__movie-year">
                        {new Date(movie.release_date).getFullYear()}
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <div className="browse__empty">
            <FilmIcon size={48} className="browse__empty-icon" />
            <p className="browse__empty-text">No movies found</p>
            <p className="browse__empty-subtext">
              We couldn't find any movies matching your selected filter. 
              Try another category or check back later.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Browse;