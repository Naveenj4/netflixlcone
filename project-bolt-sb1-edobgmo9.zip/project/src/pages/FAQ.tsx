import React, { useState } from 'react';
import { ArrowRight, Plus, Minus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import './FAQ.css';

const faqData = [
  {
    question: "What is Netflux?",
    answer: "Netflux is a streaming service that offers a wide variety of award-winning TV shows, movies, anime, documentaries, and more on thousands of internet-connected devices. You can watch as much as you want, whenever you want without a single commercial – all for one low monthly price."
  },
  {
    question: "How much does Netflux cost?",
    answer: "Watch Netflux on your smartphone, tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee. Plans range from $8.99 to $17.99 a month. No extra costs, no contracts."
  },
  {
    question: "Where can I watch?",
    answer: "Watch anywhere, anytime. Sign in with your Netflux account to watch instantly on the web at netflux.com from your personal computer or on any internet-connected device that offers the Netflux app, including smart TVs, smartphones, tablets, streaming media players and game consoles."
  },
  {
    question: "How do I cancel?",
    answer: "Netflux is flexible. There are no pesky contracts and no commitments. You can easily cancel your account online in two clicks. There are no cancellation fees – start or stop your account anytime."
  },
  {
    question: "What can I watch on Netflux?",
    answer: "Netflux has an extensive library of feature films, documentaries, TV shows, anime, award-winning Netflux originals, and more. Watch as much as you want, anytime you want."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      navigate('/signup', { state: { email } });
    }
  };

  return (
    <div className="faq">
      <div className="faq__container">
        <h1 className="faq__title">Frequently Asked Questions</h1>
        
        <div className="faq__list">
          {faqData.map((item, index) => (
            <div key={index} className="faq__item">
              <button
                className="faq__question"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                {item.question}
                {openIndex === index ? <Minus size={24} /> : <Plus size={24} />}
              </button>
              <div className={`faq__answer ${openIndex === index ? 'open' : ''}`}>
                <div className="faq__answer-content">
                  {item.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="faq__get-started">
          <p className="faq__text">
            Ready to watch? Enter your email to create or restart your membership.
          </p>
          <form className="faq__form" onSubmit={handleSubmit}>
            <input
              type="email"
              className="faq__input"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="submit" className="faq__button">
              Get Started <ArrowRight size={24} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default FAQ;