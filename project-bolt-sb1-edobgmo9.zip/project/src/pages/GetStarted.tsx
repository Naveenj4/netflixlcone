import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import './GetStarted.css';

const GetStarted: React.FC = () => {
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      navigate('/signup', { state: { email } });
    }
  };

  return (
    <div className="get-started">
      <div className="get-started__content">
        <h1 className="get-started__title">
          Unlimited movies, TV shows, and more
        </h1>
        <h2 className="get-started__subtitle">
          Watch anywhere. Cancel anytime.
        </h2>
        <form className="get-started__form" onSubmit={handleSubmit}>
          <input
            type="email"
            className="get-started__input"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button type="submit" className="get-started__button">
            Get Started <ArrowRight size={24} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default GetStarted;