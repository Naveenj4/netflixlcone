import React, { useEffect, useState } from 'react';
import Banner from '../components/Banner';
import Row from '../components/Row';
import { MovieRow } from '../types';
import { getMovieRows } from '../services/movieService';
import './Home.css';

const Home: React.FC = () => {
  const [movieRows, setMovieRows] = useState<MovieRow[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMovieRows = async () => {
      try {
        const rows = await getMovieRows();
        setMovieRows(rows);
      } catch (error) {
        console.error('Error fetching movie rows:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMovieRows();
  }, []);

  return (
    <div className="home">
      <Banner />
      <div className="container home__rows">
        {isLoading ? (
          // Show loading skeletons
          [...Array(5)].map((_, i) => (
            <Row
              key={i}
              title={`Loading...`}
              movies={[]}
              isLoading={true}
            />
          ))
        ) : (
          // Show actual movie rows
          movieRows.map((row, index) => (
            <Row
              key={index}
              title={row.title}
              movies={row.movies}
            />
          ))
        )}
      </div>
    </div>
  );
};

export default Home;