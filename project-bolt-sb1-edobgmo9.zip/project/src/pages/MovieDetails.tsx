import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Play, FilmIcon, AlertTriangle, Star } from 'lucide-react';
import { Movie } from '../types';
import { getMovieById, getSimilarMovies, getGenreName } from '../services/movieService';
import './MovieDetails.css';

const MovieDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [similarMovies, setSimilarMovies] = useState<Movie[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMovie = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        if (id) {
          const movieId = parseInt(id);
          const movieData = await getMovieById(movieId);
          
          if (movieData) {
            setMovie(movieData);
            
            // Fetch similar movies
            const similar = await getSimilarMovies(movieId);
            setSimilarMovies(similar);
          } else {
            setError('Movie not found');
          }
        }
      } catch (err) {
        console.error('Error fetching movie details:', err);
        setError('Failed to load movie details');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchMovie();
  }, [id]);

  if (isLoading) {
    return (
      <div className="movie-details__loading">
        <div className="movie-details__loading-spinner"></div>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="movie-details__error">
        <AlertTriangle size={64} className="movie-details__error-icon" />
        <h1 className="movie-details__error-message">{error || 'Movie not found'}</h1>
        <p>We couldn't find the movie you're looking for.</p>
        <button 
          className="movie-details__error-action"
          onClick={() => navigate('/browse')}
        >
          Browse Movies
        </button>
      </div>
    );
  }

  return (
    <div className="movie-details">
      <div className="movie-details__backdrop">
        <img 
          src={movie.backdrop_path} 
          alt={movie.title} 
          className="movie-details__backdrop-image"
        />
        <div className="movie-details__backdrop-overlay"></div>
      </div>
      
      <div className="container">
        <div className="movie-details__content">
          <img 
            src={movie.poster_path} 
            alt={movie.title} 
            className="movie-details__poster"
          />
          
          <div className="movie-details__info">
            <h1 className="movie-details__title">{movie.title}</h1>
            
            <div className="movie-details__meta">
              <div className="movie-details__year">
                {new Date(movie.release_date).getFullYear()}
              </div>
              <div className="movie-details__rating">
                <Star size={16} color="#FFD700" fill="#FFD700" />
                <span>{movie.vote_average.toFixed(1)}/10</span>
              </div>
            </div>
            
            <div className="movie-details__genres">
              {movie.genre_ids.map((genreId) => (
                <div key={genreId} className="movie-details__genre">
                  {getGenreName(genreId)}
                </div>
              ))}
            </div>
            
            <p className="movie-details__overview">{movie.overview}</p>
            
            <div className="movie-details__buttons">
              <button className="movie-details__button movie-details__button--play">
                <Play size={20} />
                Play
              </button>
              <button className="movie-details__button movie-details__button--trailer">
                <FilmIcon size={20} />
                Watch Trailer
              </button>
            </div>
          </div>
        </div>
        
        {similarMovies.length > 0 && (
          <div className="movie-details__similar">
            <h2 className="movie-details__similar-title">More Like This</h2>
            <div className="movie-details__similar-grid">
              {similarMovies.map(similarMovie => (
                <div key={similarMovie.id} className="movie-details__similar-movie">
                  <Link to={`/movie/${similarMovie.id}`}>
                    <img 
                      src={similarMovie.poster_path} 
                      alt={similarMovie.title} 
                      className="movie-details__similar-poster"
                    />
                    <div className="movie-details__similar-info">
                      <h3 className="movie-details__similar-title">{similarMovie.title}</h3>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MovieDetails;