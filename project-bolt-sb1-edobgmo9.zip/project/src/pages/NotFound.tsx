import React from 'react';
import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';
import './NotFound.css';

const NotFound: React.FC = () => {
  return (
    <div className="not-found">
      <div className="not-found__icon">404</div>
      <h1 className="not-found__title">Lost Your Way?</h1>
      <p className="not-found__message">
        Sorry, we can't find the page you're looking for. You'll find lots to explore on the home page.
      </p>
      <Link to="/" className="not-found__button">
        <Home size={20} />
        Home
      </Link>
    </div>
  );
};

export default NotFound;