import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import './Signup.css';

const Signup: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const initialEmail = location.state?.email || '';
  
  const [formData, setFormData] = useState({
    email: initialEmail,
    password: '',
    confirmPassword: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password === formData.confirmPassword) {
      // Here you would typically handle the signup process
      console.log('Signup successful!');
      navigate('/browse');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="signup">
      <Link to="/" className="signup__logo">
        NETFLUX
      </Link>
      <div className="signup__container">
        <h1 className="signup__title">Create Account</h1>
        <form className="signup__form" onSubmit={handleSubmit}>
          <div className="signup__input-group">
            <input
              type="email"
              name="email"
              className="signup__input"
              placeholder="Email address"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="signup__input-group">
            <input
              type="password"
              name="password"
              className="signup__input"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="signup__input-group">
            <input
              type="password"
              name="confirmPassword"
              className="signup__input"
              placeholder="Confirm password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="signup__button">
            Sign Up
          </button>
        </form>
        <p className="signup__text">
          Already have an account?{' '}
          <Link to="/login" className="signup__link">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Signup;