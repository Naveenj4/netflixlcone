import { Movie, Genre, MovieRow } from '../types';

// Mock data for genres
const genres: Genre[] = [
  { id: 28, name: 'Action' },
  { id: 12, name: 'Adventure' },
  { id: 16, name: 'Animation' },
  { id: 35, name: 'Comedy' },
  { id: 80, name: 'Crime' },
  { id: 18, name: 'Drama' },
  { id: 10751, name: 'Family' },
  { id: 14, name: 'Fantasy' },
  { id: 36, name: 'History' },
  { id: 27, name: 'Horror' },
  { id: 10402, name: 'Music' },
  { id: 9648, name: 'Mystery' },
  { id: 10749, name: 'Romance' },
  { id: 878, name: 'Science Fiction' },
  { id: 10770, name: 'TV Movie' },
  { id: 53, name: 'Thriller' },
  { id: 10752, name: 'War' },
  { id: 37, name: 'Western' },
];

// Mock movie data
const mockMovies: Movie[] = [
  {
    id: 1,
    title: 'Inception',
    overview: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.',
    backdrop_path: 'https://images.pexels.com/photos/1028600/pexels-photo-1028600.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/2774546/pexels-photo-2774546.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '2010-07-16',
    vote_average: 8.8,
    genre_ids: [28, 878, 9648],
  },
  {
    id: 2,
    title: 'The Dark Knight',
    overview: 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.',
    backdrop_path: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/10353785/pexels-photo-10353785.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '2008-07-18',
    vote_average: 9.0,
    genre_ids: [28, 80, 18],
  },
  {
    id: 3,
    title: 'Interstellar',
    overview: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.',
    backdrop_path: 'https://images.pexels.com/photos/1257860/pexels-photo-1257860.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/1169754/pexels-photo-1169754.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '2014-11-07',
    vote_average: 8.6,
    genre_ids: [12, 18, 878],
  },
  {
    id: 4,
    title: 'The Avengers',
    overview: 'Earth\'s mightiest heroes must come together and learn to fight as a team if they are going to stop the mischievous Loki and his alien army from enslaving humanity.',
    backdrop_path: 'https://images.pexels.com/photos/3573382/pexels-photo-3573382.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/9601407/pexels-photo-9601407.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '2012-05-04',
    vote_average: 8.0,
    genre_ids: [28, 12, 878],
  },
  {
    id: 5,
    title: 'The Shawshank Redemption',
    overview: 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.',
    backdrop_path: 'https://images.pexels.com/photos/2373730/pexels-photo-2373730.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/2582928/pexels-photo-2582928.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1994-09-23',
    vote_average: 9.3,
    genre_ids: [18, 80],
  },
  {
    id: 6,
    title: 'The Matrix',
    overview: 'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.',
    backdrop_path: 'https://images.pexels.com/photos/924824/pexels-photo-924824.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/1040473/pexels-photo-1040473.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1999-03-31',
    vote_average: 8.7,
    genre_ids: [28, 878],
  },
  {
    id: 7,
    title: 'Fight Club',
    overview: 'An insomniac office worker and a devil-may-care soapmaker form an underground fight club that evolves into something much, much more.',
    backdrop_path: 'https://images.pexels.com/photos/2739046/pexels-photo-2739046.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/2873479/pexels-photo-2873479.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1999-10-15',
    vote_average: 8.8,
    genre_ids: [18, 53, 35],
  },
  {
    id: 8,
    title: 'Pulp Fiction',
    overview: 'The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.',
    backdrop_path: 'https://images.pexels.com/photos/1242348/pexels-photo-1242348.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/7991486/pexels-photo-7991486.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1994-10-14',
    vote_average: 8.9,
    genre_ids: [53, 80],
  },
  {
    id: 9,
    title: 'The Lord of the Rings',
    overview: 'A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth from the Dark Lord Sauron.',
    backdrop_path: 'https://images.pexels.com/photos/358238/pexels-photo-358238.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/7809123/pexels-photo-7809123.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '2001-12-19',
    vote_average: 8.8,
    genre_ids: [12, 14, 28],
  },
  {
    id: 10,
    title: 'Forrest Gump',
    overview: 'The presidencies of Kennedy and Johnson, the events of Vietnam, Watergate, and other history unfold through the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.',
    backdrop_path: 'https://images.pexels.com/photos/5699665/pexels-photo-5699665.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/8088405/pexels-photo-8088405.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1994-07-06',
    vote_average: 8.8,
    genre_ids: [18, 35, 10749],
  },
  {
    id: 11,
    title: 'The Godfather',
    overview: 'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.',
    backdrop_path: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/247204/pexels-photo-247204.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1972-03-24',
    vote_average: 9.2,
    genre_ids: [18, 80],
  },
  {
    id: 12,
    title: 'The Silence of the Lambs',
    overview: 'A young F.B.I. cadet must receive the help of an incarcerated and manipulative cannibal killer to help catch another serial killer, a madman who skins his victims.',
    backdrop_path: 'https://images.pexels.com/photos/1034662/pexels-photo-1034662.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    poster_path: 'https://images.pexels.com/photos/2681319/pexels-photo-2681319.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
    release_date: '1991-02-14',
    vote_average: 8.6,
    genre_ids: [27, 53, 80],
  },
];

// Helper function to get random movies from the mock data
const getRandomMovies = (count: number): Movie[] => {
  const shuffled = [...mockMovies].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};

// Get a featured movie for the banner
export const getFeaturedMovie = async (): Promise<Movie> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockMovies[Math.floor(Math.random() * 5)]);
    }, 500);
  });
};

// Get movie by ID
export const getMovieById = async (id: number): Promise<Movie | undefined> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockMovies.find(movie => movie.id === id));
    }, 500);
  });
};

// Get similar movies
export const getSimilarMovies = async (id: number): Promise<Movie[]> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      const movie = mockMovies.find(m => m.id === id);
      if (!movie) {
        resolve([]);
        return;
      }
      
      const similarMovies = mockMovies
        .filter(m => m.id !== id && m.genre_ids.some(g => movie.genre_ids.includes(g)))
        .slice(0, 6);
      
      resolve(similarMovies);
    }, 500);
  });
};

// Get movie rows categorized by genre or type
export const getMovieRows = async (): Promise<MovieRow[]> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      const rows: MovieRow[] = [
        { title: 'Trending Now', movies: getRandomMovies(8) },
        { title: 'Top Rated', movies: [...mockMovies].sort((a, b) => b.vote_average - a.vote_average).slice(0, 8) },
        { title: 'Action Movies', movies: mockMovies.filter(movie => movie.genre_ids.includes(28)).slice(0, 8) },
        { title: 'Sci-Fi Movies', movies: mockMovies.filter(movie => movie.genre_ids.includes(878)).slice(0, 8) },
        { title: 'Drama', movies: mockMovies.filter(movie => movie.genre_ids.includes(18)).slice(0, 8) },
      ];
      
      resolve(rows);
    }, 800);
  });
};

// Get all genres
export const getGenres = async (): Promise<Genre[]> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(genres);
    }, 300);
  });
};

// Get genre name by ID
export const getGenreName = (id: number): string => {
  const genre = genres.find(g => g.id === id);
  return genre ? genre.name : 'Unknown';
};

// Search movies
export const searchMovies = async (query: string): Promise<Movie[]> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      const results = mockMovies.filter(movie => 
        movie.title.toLowerCase().includes(query.toLowerCase()) || 
        movie.overview.toLowerCase().includes(query.toLowerCase())
      );
      resolve(results);
    }, 500);
  });
};